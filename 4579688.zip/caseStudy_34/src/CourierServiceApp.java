/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author Akash
 */

import java.sql.*;
import java.util.Scanner;

public class CourierServiceApp {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/courier_service";
    private static final String USER = "root";
    private static final String PASS = "Akash123";
    private Connection connection;
    
    public static void main(String[] args) {
        CourierServiceApp courierService = new CourierServiceApp();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Courier Service Management System");
            System.out.println("1. Add Parcel");
            System.out.println("2. View Parcel");
            System.out.println("3. Update Parcel");
            System.out.println("4. Delete Parcel");
            System.out.println("5. Register Customer");
            System.out.println("6. View Customer");
            System.out.println("7. Update Customer");
            System.out.println("8. Delete Customer");
            System.out.println("9. Schedule Delivery");
            System.out.println("10. Update Delivery Status");
            System.out.println("11. Exit");

            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter sender name: ");
                    String senderName = scanner.next();
                    scanner.nextLine();
                    System.out.print("Enter sender address: ");
                    String senderAddress = scanner.next();
                    scanner.nextLine();
                    System.out.print("Enter recipient name: ");
                    String recipientName = scanner.next();
                    scanner.nextLine();
                    System.out.print("Enter recipient address: ");
                    String recipientAddress = scanner.next();
                    scanner.nextLine();
                    System.out.print("Enter weight: ");
                    double weight = scanner.nextDouble();
                    courierService.addParcel(senderName, senderAddress, recipientName, recipientAddress, weight);
                    break;
                case 2:
                    System.out.print("Enter parcel ID: ");
                    int parcelId = scanner.nextInt();
                    courierService.viewParcel(parcelId);
                    break;
                case 3:
                    System.out.print("Enter parcel ID: ");
                    parcelId = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter sender name: ");
                    senderName = scanner.next();
                    scanner.nextLine();
                    System.out.print("Enter sender address: ");
                    senderAddress = scanner.next();
                    scanner.nextLine();
                    System.out.print("Enter recipient name: ");
                    recipientName = scanner.next();
                    scanner.nextLine();
                    System.out.print("Enter recipient address: ");
                    recipientAddress = scanner.next();
                    scanner.nextLine();
                    System.out.print("Enter weight: ");
                    weight = scanner.nextDouble();
                    courierService.updateParcel(parcelId, senderName, senderAddress, recipientName, recipientAddress, weight);
                    break;
                case 4:
                    System.out.print("Enter parcel ID: ");
                    parcelId = scanner.nextInt();
                    courierService.deleteParcel(parcelId);
                    break;
                case 5:
                    System.out.print("Enter customer name: ");
                    String customerName = scanner.next();
                    scanner.nextLine();
                    System.out.print("Enter email: ");
                    String email = scanner.next();
                    scanner.nextLine();
                    System.out.print("Enter phone number: ");
                    String phoneNumber = scanner.next();
                    scanner.nextLine();
                    System.out.print("Enter customer Address : ");
                    String customerAddress = scanner.next();
                    courierService.registerCustomer(customerName, email, phoneNumber, customerAddress);
                    break;

                case 6:
                    System.out.print("Enter customer ID: ");
                    int customerId = scanner.nextInt();
                    courierService.viewCustomer(customerId);
                    break;
                case 7:
                    System.out.print("Enter customer ID: ");
                    customerId = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter customer name: ");
                    customerName = scanner.next();
                    scanner.nextLine();
                    System.out.print("Enter email: ");
                    email = scanner.next();
                    scanner.nextLine();
                    System.out.print("Enter phone number: ");
                    phoneNumber = scanner.next();
                    scanner.nextLine();
                    System.out.println("Enter customer Address : ");
                    customerAddress = scanner.next();
                    courierService.updateCustomer(customerId, customerName, email, phoneNumber, customerAddress);
                    break;
                case 8:
                    System.out.print("Enter customer ID: ");
                    customerId = scanner.nextInt();
                    courierService.deleteCustomer(customerId);
                    break;
                case 9:
                    System.out.print("Enter parcel ID: ");
                    parcelId = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter customer ID: ");
                    customerId = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter delivery date (yyyy-mm-dd): ");
                    String deliveryDateStr = scanner.next();
                    scanner.nextLine();
                    Date deliveryDate = Date.valueOf(deliveryDateStr);
                    courierService.scheduleDelivery(parcelId, customerId, deliveryDate);
                    break;
                case 10:
                    System.out.print("Enter delivery ID: ");
                    int deliveryId = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter status: ");
                    String status = scanner.next();
                    scanner.nextLine();
                    courierService.updateDeliveryStatus(deliveryId, status);
                    break;
                case 11:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
    
    public CourierServiceApp() {
        try {
            connection = DriverManager.getConnection(DB_URL, USER, PASS);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addParcel(String senderName, String senderAddress, String recipientName, String recipientAddress, double weight) {
        String query = "INSERT INTO Parcel (sender_name, sender_address, recipient_name, recipient_address, weight, status) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, senderName);
            pstmt.setString(2, senderAddress);
            pstmt.setString(3, recipientName);
            pstmt.setString(4, recipientAddress);
            pstmt.setDouble(5, weight);
            pstmt.setString(6, "Scheduled");
            pstmt.executeUpdate();
            System.out.println("Parcel added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewParcel(int parcelId) {
        String query = "SELECT * FROM Parcel WHERE parcel_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, parcelId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                System.out.println("Parcel ID: " + rs.getInt("parcel_id"));
                System.out.println("Sender Name: " + rs.getString("sender_name"));
                System.out.println("Sender Address: " + rs.getString("sender_address"));
                System.out.println("Recipient Name: " + rs.getString("recipient_name"));
                System.out.println("Recipient Address: " + rs.getString("recipient_address"));
                System.out.println("Weight: " + rs.getDouble("weight"));
                System.out.println("Status: " + rs.getString("status"));
            } else {
                System.out.println("Parcel not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateParcel(int parcelId, String senderName, String senderAddress, String recipientName, String recipientAddress, double weight) {
        String query = "UPDATE Parcel SET sender_name = ?, sender_address = ?, recipient_name = ?, recipient_address = ?, weight = ? WHERE parcel_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, senderName);
            pstmt.setString(2, senderAddress);
            pstmt.setString(3, recipientName);
            pstmt.setString(4, recipientAddress);
            pstmt.setDouble(5, weight);
            pstmt.setInt(6, parcelId);
            pstmt.executeUpdate();
            System.out.println("Parcel updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteParcel(int parcelId) {
        String query = "DELETE FROM Parcel WHERE parcel_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, parcelId);
            pstmt.executeUpdate();
            System.out.println("Parcel deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void registerCustomer(String customerName, String email, String phoneNumber, String customerAddress) {
        String query = "INSERT INTO Customer (customer_name, email, customer_phone_number, customer_address) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, customerName);
            pstmt.setString(2, email);
            pstmt.setString(3, phoneNumber);
            pstmt.setString(4, customerAddress);
            pstmt.executeUpdate();
            System.out.println("Customer registered successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewCustomer(int customerId) {
        String query = "SELECT * FROM Customer WHERE customer_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, customerId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                System.out.println("Customer ID: " + rs.getInt("customer_id"));
                System.out.println("Customer Name: " + rs.getString("customer_name"));
                System.out.println("Email: " + rs.getString("email"));
                System.out.println("Phone Number: " + rs.getString("customer_phone_number"));
                System.out.println("Address: " + rs.getString("customer_address"));
            } else {
                System.out.println("Customer not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateCustomer(int customerId, String customerName, String email, String phoneNumber, String customerAddress) {
        String query = "UPDATE Customer SET customer_name = ?, email = ?, phone_number = ?, customer_address WHERE customer_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, customerName);
            pstmt.setString(2, email);
            pstmt.setString(3, phoneNumber);
            pstmt.setString(4, customerAddress);
            pstmt.setInt(5, customerId);
            pstmt.executeUpdate();
            System.out.println("Customer updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteCustomer(int customerId) {
        String query = "DELETE FROM Customer WHERE customer_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, customerId);
            pstmt.executeUpdate();
            System.out.println("Customer deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void scheduleDelivery(int parcelId, int customerId, Date deliveryDate) {
        String query = "INSERT INTO Delivery (parcel_id, customer_id, delivery_date, delivery_status, delivery_cost) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, parcelId);
            pstmt.setInt(2, customerId);
            pstmt.setDate(3, deliveryDate);
            pstmt.setString(4, "Scheduled");
            pstmt.setDouble(5, calculateDeliveryCost(parcelId));
            pstmt.executeUpdate();
            System.out.println("Delivery scheduled successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateDeliveryStatus(int deliveryId, String status) {
        try (PreparedStatement pstmt = connection.prepareStatement("UPDATE Delivery SET delivery_status = ? WHERE delivery_id = ?")) {
            pstmt.setString(1, status);
            pstmt.setInt(2, deliveryId);
            pstmt.executeUpdate();
            System.out.println("Delivery status updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    private double calculateDeliveryCost(int parcelId) {
        String query = "SELECT weight FROM Parcel WHERE parcel_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, parcelId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                double weight = rs.getDouble("weight");
                double ratePerKg = 10.0;
                return weight * ratePerKg;
            } else {
                return 0.0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return 0.0;
        }
    }
}